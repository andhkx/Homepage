from flask import Flask, render_template, request, redirect, url_for, session, flash
from datetime import datetime, date
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'andhika_secret_key_2025_uas_rpl'

def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='uas11rpl_andhika_ap'
    )

@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username_andhika = request.form.get('username_andhika')
        password_andhika = request.form.get('password_andhika')

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT no_pengguna_andhika, username_andhika, password_andhika, pengguna_andhika FROM pengguna_andhika WHERE username_andhika = %s", (username_andhika,))
            row = cursor.fetchone()
            cursor.close()
            conn.close()

            if not row:
                error = "Username tidak ditemukan"
            else:
                password_hash_andhika = row[2]
                if check_password_hash(password_hash_andhika, password_andhika):
                    session['logged_in_andhika'] = True
                    session['no_pengguna_andhika'] = row[0]
                    session['username_andhika'] = row[1]
                    session['nama_pengguna_andhika'] = row[3]
                    return redirect(url_for('dashboard'))
                else:
                    error = "Password salah"
        except Exception as e:
            error = f"Kesalahan saat mengecek kredensial: {str(e)}"

    return render_template('login_Andhika.html', error=error)

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM produk_andhika")
        count_produk_andhika = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM kategori_produk_andhika")
        count_kategori_andhika = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM penjualan_andhika")
        count_transaksi_andhika = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM pengguna_andhika")
        count_pengguna_andhika = cursor.fetchone()[0]
        
        cursor.execute("SELECT COALESCE(SUM(total_belanja_andhika), 0) FROM penjualan_andhika")
        total_omzet_andhika = cursor.fetchone()[0]
        
        cursor.close()
        conn.close()
        
        return render_template('dashboard_Andhika.html', 
                             count_produk=count_produk_andhika,
                             count_kategori=count_kategori_andhika,
                             count_transaksi=count_transaksi_andhika,
                             count_pengguna=count_pengguna_andhika,
                             total_omzet=total_omzet_andhika,
                             nama_user=session.get('nama_pengguna_andhika'))
    except Exception as e:
        return f"Error saat mengambil data dashboard: {str(e)}"

@app.route('/produk', methods=['GET', 'POST'])
def produk():
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM produk_andhika ORDER BY no_produk_andhika ASC")
        list_produk = cursor.fetchall()
        cursor.close()
        conn.close()
        message = "Koneksi ke database berhasil!"
    except Exception as e:
        list_produk = []
        message = f"Koneksi ke database gagal: {str(e)}"
    return render_template('crud_Andhika.html', list_produk=list_produk, message=message)

@app.route('/input', methods=['GET', 'POST'])
def input():
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        no_produk_andhika = request.form['no_produk_andhika']
        nama_produk_andhika = request.form['nama_produk_andhika']
        no_kategori_andhika = request.form['no_kategori_andhika']
        harga_beli_andhika = request.form['harga_beli_andhika']
        harga_jual_andhika = request.form['harga_jual_andhika']
        stok_andhika = request.form['stok_andhika']
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            sql = "INSERT INTO produk_andhika (no_produk_andhika, nama_produk_andhika, no_kategori_andhika, harga_beli_andhika, harga_jual_andhika, stok_andhika) VALUES (%s, %s, %s, %s, %s, %s)"
            val = (no_produk_andhika, nama_produk_andhika, no_kategori_andhika, harga_beli_andhika, harga_jual_andhika, stok_andhika)
            cursor.execute(sql, val)
            conn.commit()
            cursor.close()
            conn.close()
            return redirect(url_for('produk', messageDhika=1))
        except Exception as e:
            return f"Terjadi kesalahan saat memasukkan data: {str(e)}"
    else:
        return render_template('form_Andhika.html')

@app.route('/edit_andhika/<no_produk_andhika>', methods=['GET', 'POST'])
def edit(no_produk_andhika):
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        nama_produk_andhika = request.form['nama_produk_andhika']
        no_kategori_andhika = request.form['no_kategori_andhika']
        harga_beli_andhika = request.form['harga_beli_andhika']
        harga_jual_andhika = request.form['harga_jual_andhika']
        stok_andhika = request.form['stok_andhika']
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            sql = "UPDATE produk_andhika SET nama_produk_andhika=%s, no_kategori_andhika=%s, harga_beli_andhika=%s, harga_jual_andhika=%s, stok_andhika=%s WHERE no_produk_andhika=%s"
            val = (nama_produk_andhika, no_kategori_andhika, harga_beli_andhika, harga_jual_andhika, stok_andhika, no_produk_andhika)
            cursor.execute(sql, val)
            conn.commit()
            cursor.close()
            conn.close()
            return redirect(url_for('produk', messageDhika=2))
        except Exception as e:
            return f"Terjadi kesalahan saat mengupdate data: {str(e)}"
    else:
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM produk_andhika WHERE no_produk_andhika = %s", (no_produk_andhika,))
            produk = cursor.fetchone()
            cursor.close()
            conn.close()
            if produk:
                return render_template('edit_Andhika.html', s=produk)
            else:
                return "Data tidak ditemukan", 404
        except Exception as e:
            return f"Terjadi kesalahan saat mengambil data: {str(e)}"

@app.route('/delete/<no_produk_andhika>', methods=['POST'])
def delete(no_produk_andhika):
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM produk_andhika WHERE no_produk_andhika=%s", (no_produk_andhika,))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('produk', messageDhika=3))
    except Exception as e:
        return f"Terjadi kesalahan saat menghapus data: {str(e)}"

@app.route('/transaksi', methods=['GET', 'POST'])
def transaksi():
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    if request.method == 'GET':
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT no_produk_andhika, nama_produk_andhika, no_kategori_andhika, harga_jual_andhika, stok_andhika FROM produk_andhika WHERE stok_andhika > 0 ORDER BY nama_produk_andhika")
            products = cursor.fetchall()
            cursor.execute("SELECT no_pengguna_andhika, username_andhika, pengguna_andhika FROM pengguna_andhika ORDER BY pengguna_andhika")
            users = cursor.fetchall()
            cursor.execute("SELECT no_penjual_andhika, nama_penjual_andhika FROM penjual_andhika ORDER BY nama_penjual_andhika")
            sellers = cursor.fetchall()
            cursor.close()
            conn.close()
        except Exception as e:
            return f"Gagal memuat data untuk form transaksi: {str(e)}"
        return render_template('transaksi_form_Andhika.html', products=products, users=users, sellers=sellers)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        no_pengguna = request.form.get('no_pengguna_andhika')
        no_penjual = request.form.get('no_penjual_andhika')
        product_list = request.form.getlist('product[]')
        qty_list = request.form.getlist('qty[]')

        if not product_list or len(product_list) == 0:
            return "Pilih minimal satu produk", 400

        cursor.execute("SELECT no_transaksi_andhika FROM penjualan_andhika ORDER BY no_transaksi_andhika DESC LIMIT 1")
        last = cursor.fetchone()
        if last and last[0].startswith('TR'):
            num = int(last[0][2:]) + 1
        else:
            num = 1
        no_transaksi = f"TR{num:03d}"
        tanggal = date.today().strftime('%Y-%m-%d')

        total_belanja = 0
        details = []
        for prod_id, qty_raw in zip(product_list, qty_list):
            try:
                qty = int(qty_raw)
            except:
                qty = 0
            if qty <= 0:
                continue
            
            cursor.execute("SELECT harga_jual_andhika, no_kategori_andhika, stok_andhika FROM produk_andhika WHERE no_produk_andhika = %s", (prod_id,))
            p = cursor.fetchone()
            if not p:
                continue
            
            harga_jual, no_kategori, stok = p[0], p[1], p[2]
            
            if qty > stok:
                cursor.close()
                conn.close()
                return f"Stok produk {prod_id} tidak mencukupi! Stok tersedia: {stok}", 400
            
            cursor.execute("SELECT nama_kategori_andhika FROM kategori_produk_andhika WHERE no_kategori_andhika = %s", (no_kategori,))
            kat = cursor.fetchone()
            nama_kategori = kat[0] if kat else ''
            subtotal = harga_jual * qty
            total_belanja += subtotal
            details.append((no_transaksi, prod_id, no_kategori, nama_kategori, qty))

        if len(details) == 0:
            cursor.close()
            conn.close()
            return "Tidak ada detail transaksi valid.", 400

        try:
            conn.start_transaction()
            cursor.execute(
                "INSERT INTO penjualan_andhika (no_transaksi_andhika, tanggal_andhika, no_pengguna_andhika, no_penjual_andhika, total_belanja_andhika) VALUES (%s, %s, %s, %s, %s)",
                (no_transaksi, tanggal, no_pengguna, no_penjual, total_belanja)
            )
            for d in details:
                cursor.execute(
                    "INSERT INTO detail_penjualan_andhika (no_transaksi_andhika, no_produk_andhika, no_kategori_andhika, nama_kategori_andhika, qty_andhika) VALUES (%s, %s, %s, %s, %s)",
                    d
                )
                cursor.execute(
                    "UPDATE produk_andhika SET stok_andhika = stok_andhika - %s WHERE no_produk_andhika = %s",
                    (d[4], d[1])
                )
            conn.commit()
        except Exception as e:
            conn.rollback()
            cursor.close()
            conn.close()
            return f"Gagal menyimpan transaksi: {str(e)}", 500

        cursor.close()
        conn.close()
        return redirect(url_for('transaksi_list'))

    except Exception as e:
        return f"Terjadi kesalahan saat memproses transaksi: {str(e)}", 500

@app.route('/transaksi/list', methods=['GET'])
def transaksi_list():
    if not session.get('logged_in_andhika'):
        return redirect(url_for('login'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT h.no_transaksi_andhika, h.tanggal_andhika, h.no_pengguna_andhika, u.pengguna_andhika, h.no_penjual_andhika, p.nama_penjual_andhika, h.total_belanja_andhika "
            "FROM penjualan_andhika h "
            "LEFT JOIN pengguna_andhika u ON h.no_pengguna_andhika = u.no_pengguna_andhika "
            "LEFT JOIN penjual_andhika p ON h.no_penjual_andhika = p.no_penjual_andhika "
            "ORDER BY h.tanggal_andhika DESC, h.no_transaksi_andhika DESC"
        )
        headers = cursor.fetchall()

        transaksi_full = []
        for h in headers:
            no_tr = h[0]
            cursor.execute(
                "SELECT d.no_produk_andhika, pr.nama_produk_andhika, d.no_kategori_andhika, d.nama_kategori_andhika, d.qty_andhika, pr.harga_jual_andhika, (d.qty_andhika * pr.harga_jual_andhika) as subtotal "
                "FROM detail_penjualan_andhika d "
                "LEFT JOIN produk_andhika pr ON d.no_produk_andhika = pr.no_produk_andhika "
                "WHERE d.no_transaksi_andhika = %s",
                (no_tr,)
            )
            details = cursor.fetchall()
            transaksi_full.append({'header': h, 'details': details})

        cursor.execute("SELECT COALESCE(SUM(total_belanja_andhika),0), COUNT(*) FROM penjualan_andhika")
        agg = cursor.fetchone()
        total_omzet = agg[0] if agg else 0
        total_transaksi = agg[1] if agg else 0

        cursor.close()
        conn.close()
        return render_template('transaksi_list_Andhika.html', 
                             transaksi_full=transaksi_full, 
                             total_transaksi=total_transaksi, 
                             total_omzet=total_omzet)
    except Exception as e:
        return f"Gagal mengambil daftar transaksi: {str(e)}"

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)