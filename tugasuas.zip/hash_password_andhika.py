from werkzeug.security import generate_password_hash

print("=== HASH PASSWORD GENERATOR ANDHIKA ===\n")

passwords_to_hash = {
    "andhika (2733)": "2733",
    "rikoo (123)": "123"
}

for label, password in passwords_to_hash.items():
    hashed = generate_password_hash(password)
    print(f"{label}:")
    print(f"Original: {password}")
    print(f"Hashed: {hashed}")
    username = label.split()[0]  # Extracting the username part
    # Make sure username matches what's in your DB schema
    print(f"\nUPDATE pengguna_andhika SET password_andhika = '{hashed}' WHERE username_andhika = '{username}';\n")
    print("-" * 80)
    print()