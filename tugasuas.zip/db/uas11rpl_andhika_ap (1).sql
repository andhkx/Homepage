SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `uas11rpl_andhika_ap`;
USE `uas11rpl_andhika_ap`;

CREATE TABLE `detail_penjualan_andhika` (
  `id_detail_andhika` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi_andhika` varchar(5) NOT NULL,
  `no_produk_andhika` varchar(5) NOT NULL,
  `no_kategori_andhika` varchar(5) NOT NULL,
  `nama_kategori_andhika` varchar(15) NOT NULL,
  `qty_andhika` int(3) NOT NULL,
  PRIMARY KEY (`id_detail_andhika`),
  KEY `no_transaksi_andhika` (`no_transaksi_andhika`),
  KEY `no_produk_andhika` (`no_produk_andhika`),
  KEY `no_kategori_andhika` (`no_kategori_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `detail_penjualan_andhika` (`id_detail_andhika`, `no_transaksi_andhika`, `no_produk_andhika`, `no_kategori_andhika`, `nama_kategori_andhika`, `qty_andhika`) VALUES
(1, 'TR001', 'PR001', 'KT001', 'Tanah Liat', 3),
(2, 'TR002', 'PR002', 'KT002', 'Sampah', 2);

CREATE TABLE `kategori_produk_andhika` (
  `no_kategori_andhika` varchar(5) NOT NULL,
  `nama_kategori_andhika` varchar(15) NOT NULL,
  `keterangan_andhika` varchar(50) NOT NULL,
  PRIMARY KEY (`no_kategori_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `kategori_produk_andhika` (`no_kategori_andhika`, `nama_kategori_andhika`, `keterangan_andhika`) VALUES
('KT001', 'Tanah Liat', 'Kerajinan tangan dari tanah liat'),
('KT002', 'Sampah', 'Kerajinan tangan dari sampah daur ulang');

CREATE TABLE `pengguna_andhika` (
  `no_pengguna_andhika` varchar(5) NOT NULL,
  `username_andhika` varchar(10) NOT NULL,
  `password_andhika` varchar(255) NOT NULL,
  `pengguna_andhika` varchar(15) NOT NULL,
  `jk_andhika` enum('Laki-laki','Perempuan') NOT NULL,
  PRIMARY KEY (`no_pengguna_andhika`),
  UNIQUE KEY `username_andhika` (`username_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pengguna_andhika` (`no_pengguna_andhika`, `username_andhika`, `password_andhika`, `pengguna_andhika`, `jk_andhika`) VALUES
('PG001', 'andhika', 'scrypt:32768:8:1$3cRbCuEMQWrxMLYU$dc8be34e1f847e8a56e5e56e0c36ce5e9fc84e5deee3a6b44b3c0f2f7c8a0e5f2b1c4d3e7c9a8f6b0e1d2a3c4b5f6a7e8d9c0b1a2e3d4c5f6a7b8c9d0e1f2a3b4c5', 'Andhika', 'Laki-laki'),
('PG002', 'rikoo', 'scrypt:32768:8:1$1WZvHqQEzsPmAKJH$8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b', 'Paris', 'Laki-laki');

CREATE TABLE `penjualan_andhika` (
  `no_transaksi_andhika` varchar(5) NOT NULL,
  `tanggal_andhika` date NOT NULL,
  `no_pengguna_andhika` varchar(5) NOT NULL,
  `no_penjual_andhika` varchar(5) NOT NULL,
  `total_belanja_andhika` int(7) NOT NULL,
  PRIMARY KEY (`no_transaksi_andhika`),
  KEY `no_pengguna_andhika` (`no_pengguna_andhika`),
  KEY `no_penjual_andhika` (`no_penjual_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `penjualan_andhika` (`no_transaksi_andhika`, `tanggal_andhika`, `no_pengguna_andhika`, `no_penjual_andhika`, `total_belanja_andhika`) VALUES
('TR001', '2025-11-01', 'PG001', 'PJ001', 90000),
('TR002', '2025-11-02', 'PG002', 'PJ002', 20000);

CREATE TABLE `penjual_andhika` (
  `no_penjual_andhika` varchar(5) NOT NULL,
  `nama_penjual_andhika` varchar(15) NOT NULL,
  `jk_penjual_andhika` enum('Laki-laki','Perempuan') NOT NULL,
  `alamat_andhika` varchar(50) NOT NULL,
  `no_telp_andhika` varchar(15) NOT NULL,
  PRIMARY KEY (`no_penjual_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `penjual_andhika` (`no_penjual_andhika`, `nama_penjual_andhika`, `jk_penjual_andhika`, `alamat_andhika`, `no_telp_andhika`) VALUES
('PJ001', 'Adit', 'Laki-laki', 'Jl. Kolmas', '081314642341'),
('PJ002', 'Haidar', 'Laki-laki', 'Jl. Puri', '081234123652');

CREATE TABLE `produk_andhika` (
  `no_produk_andhika` varchar(5) NOT NULL,
  `nama_produk_andhika` varchar(15) NOT NULL,
  `no_kategori_andhika` varchar(5) NOT NULL,
  `harga_beli_andhika` int(7) NOT NULL,
  `harga_jual_andhika` int(7) NOT NULL,
  `stok_andhika` int(3) NOT NULL,
  PRIMARY KEY (`no_produk_andhika`),
  KEY `no_kategori_andhika` (`no_kategori_andhika`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `produk_andhika` (`no_produk_andhika`, `nama_produk_andhika`, `no_kategori_andhika`, `harga_beli_andhika`, `harga_jual_andhika`, `stok_andhika`) VALUES
('PR001', 'Vas Bunga', 'KT001', 15000, 30000, 5),
('PR002', 'Karpet', 'KT002', 5000, 10000, 10);

ALTER TABLE `detail_penjualan_andhika`
  ADD CONSTRAINT `detail_penjualan_andhika_ibfk_1` FOREIGN KEY (`no_transaksi_andhika`) REFERENCES `penjualan_andhika` (`no_transaksi_andhika`) ON DELETE CASCADE,
  ADD CONSTRAINT `detail_penjualan_andhika_ibfk_2` FOREIGN KEY (`no_produk_andhika`) REFERENCES `produk_andhika` (`no_produk_andhika`),
  ADD CONSTRAINT `detail_penjualan_andhika_ibfk_3` FOREIGN KEY (`no_kategori_andhika`) REFERENCES `kategori_produk_andhika` (`no_kategori_andhika`);

ALTER TABLE `penjualan_andhika`
  ADD CONSTRAINT `penjualan_andhika_ibfk_1` FOREIGN KEY (`no_pengguna_andhika`) REFERENCES `pengguna_andhika` (`no_pengguna_andhika`),
  ADD CONSTRAINT `penjualan_andhika_ibfk_2` FOREIGN KEY (`no_penjual_andhika`) REFERENCES `penjual_andhika` (`no_penjual_andhika`);

ALTER TABLE `produk_andhika`
  ADD CONSTRAINT `produk_andhika_ibfk_1` FOREIGN KEY (`no_kategori_andhika`) REFERENCES `kategori_produk_andhika` (`no_kategori_andhika`);

COMMIT;