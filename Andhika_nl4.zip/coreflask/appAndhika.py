from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('form_nl4_Andhika.html')

@app.route('/nl4', methods=['GET', 'POST'])
def input_nl4():
    if request.method == "POST":
        akhirDhika = int(request.form['akhirDhika'])
        
        segitigaDhika = []
        for i in range(akhirDhika):
            baris = [1] * (i + 1)
            for j in range(1, i):
                baris[j] = segitigaDhika[i-1][j-1] + segitigaDhika[i-1][j]
            segitigaDhika.append(baris)
        
        hasilDhika = ""
        for baris in segitigaDhika:
            hasilDhika += ' '.join(str(x) for x in baris) + "<br>"
        
        return render_template('hasil_nl4_Andhika.html', 
                             akhirDhika=akhirDhika,
                             hasilDhika=hasilDhika)
    return render_template('form_nl4_Andhika.html')

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5003)