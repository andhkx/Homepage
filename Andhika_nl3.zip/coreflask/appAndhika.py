from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('form_nl3_Andhika.html')

@app.route('/nl3', methods=['GET', 'POST'])
def input_nl3():
    if request.method == "POST":
        akhirDhika = int(request.form['akhirDhika'])
        
        hasilDhika = ""
        for i in range(1, akhirDhika + 1):
            for j in range(1, akhirDhika + 1):
                hasilDhika += str(i) + " "
            hasilDhika += "<br>"
        
        return render_template('hasil_nl3_Andhika.html', 
                             akhirDhika=akhirDhika,
                             hasilDhika=hasilDhika)
    return render_template('form_nl3_Andhika.html')

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5002)