from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('form_nl5_Andhika.html')

@app.route('/nl5', methods=['GET', 'POST'])
def input_nl5():
    if request.method == "POST":
        jumlahKelasDhika = int(request.form['jumlahKelasDhika'])
        jumlahSiswaDhika = int(request.form['jumlahSiswaDhika'])
        
        return render_template('form_nl5b_Andhika.html',
                             jumlahKelasDhika=jumlahKelasDhika,
                             jumlahSiswaDhika=jumlahSiswaDhika)
    return render_template('form_nl5_Andhika.html')

@app.route('/nl5/proses', methods=['POST'])
def proses_nl5():
    jumlahKelasDhika = int(request.form['jumlahKelasDhika'])
    jumlahSiswaDhika = int(request.form['jumlahSiswaDhika'])
    
    dataNilaiDhika = []
    totalSemuaDhika = 0
    
    for i in range(jumlahKelasDhika):
        totalKelasDhika = 0
        nilaiSiswaDhika = []
        namaSiswaDhika = []
        
        for j in range(jumlahSiswaDhika):
            namaDhika = request.form[f'nama_{i}_{j}']
            nilaiDhika = float(request.form[f'nilai_{i}_{j}'])
            namaSiswaDhika.append(namaDhika)
            nilaiSiswaDhika.append(nilaiDhika)
            totalKelasDhika += nilaiDhika
        
        rataKelasDhika = totalKelasDhika / jumlahSiswaDhika
        totalSemuaDhika += totalKelasDhika
        
        dataNilaiDhika.append({
            'nama': namaSiswaDhika,
            'nilai': nilaiSiswaDhika,
            'rata': rataKelasDhika
        })
    
    rataSemuaDhika = totalSemuaDhika / (jumlahKelasDhika * jumlahSiswaDhika)
    
    return render_template('hasil_nl5_Andhika.html',
                         dataNilaiDhika=dataNilaiDhika,
                         jumlahKelasDhika=jumlahKelasDhika,
                         jumlahSiswaDhika=jumlahSiswaDhika,
                         totalSemuaDhika=totalSemuaDhika,
                         rataSemuaDhika=rataSemuaDhika)

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5004)